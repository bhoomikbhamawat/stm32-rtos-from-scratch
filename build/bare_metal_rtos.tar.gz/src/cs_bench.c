/*
 * cs_bench.c - Measures task-to-task context-switch latency with the DWT
 *              cycle counter, over CS_BENCH_SAMPLES switches.
 *
 * Method ("ping-pong"):
 *   Two tasks, A and B, at the same top priority, take turns:
 *
 *       A: t0 = CYCCNT; os_yield();  ──────────►  B: t1 = CYCCNT (resumes)
 *                                                 record(t1 - t0 - calib)
 *                                                 t0 = CYCCNT; os_yield();
 *       A: t1 = CYCCNT (resumes)     ◄──────────
 *          record(t1 - t0 - calib) ...
 *
 *   Each sample therefore covers the FULL switch as a task experiences it:
 *     os_yield() setting PENDSVSET + DSB/ISB
 *     -> exception entry (hardware stacks 8 words)
 *     -> PendSV: save R4-R11/EXC_RETURN, run the scheduler, restore
 *     -> exception return (hardware unstacks) -> back in the other task.
 *   `calib` = cost of one CYCCNT read, measured at start-up and subtracted.
 *
 * Isolation: SysTick is paused for the run (os_tick_suspend), and both tasks
 * sit above every other task, so no tick or other task can land inside a
 * measured window. Nothing else in this project uses interrupts.
 *
 * Results land in g_cs (min / avg / max) and the raw samples in
 * g_cs_samples[] for percentile analysis on the host (tools/analyze_cs.py).
 */
#include "cs_bench.h"
#include "os.h"
#include "dwt.h"
#include "clock.h"

volatile cs_stats_t g_cs;
__attribute__((section(".ccmram"))) uint16_t g_cs_samples[CS_BENCH_SAMPLES];

static uint32_t s_stack_a[256] __attribute__((aligned(8)));
static uint32_t s_stack_b[256] __attribute__((aligned(8)));

static volatile uint32_t s_t_yield;   /* timestamp written just before yielding */
static volatile uint32_t s_arrived;
static volatile uint32_t s_armed;
static volatile uint32_t s_finished;

void __attribute__((noinline)) cs_bench_complete(void)
{
    __asm volatile ("" ::: "memory");   /* GDB: break cs_bench_complete */
}

static uint32_t measure_read_overhead(void)
{
    uint32_t best = 0xFFFFFFFFUL;
    for (uint32_t i = 0; i < 32U; i++) {
        uint32_t a = dwt_cycles();
        uint32_t b = dwt_cycles();
        if ((b - a) < best) {
            best = b - a;
        }
    }
    return best;
}

static void record(uint32_t delta)
{
    if (g_cs.count >= CS_BENCH_SAMPLES) {
        return;
    }
    uint32_t c = (delta > g_cs.calib) ? (delta - g_cs.calib) : 0U;
    g_cs_samples[g_cs.count] = (c > 0xFFFFU) ? 0xFFFFU : (uint16_t)c;
    g_cs.sum += c;
    if (c < g_cs.min) {
        g_cs.min = c;
    }
    if (c > g_cs.max) {
        g_cs.max       = c;
        g_cs.max_index = g_cs.count;
    }
    g_cs.count++;
}

static void finalize(void)
{
    uint32_t n = (g_cs.count != 0U) ? g_cs.count : 1U;
    g_cs.avg_x100 = (uint32_t)((g_cs.sum * 100ULL + n / 2U) / n);
    g_cs.avg      = (g_cs.avg_x100 + 50U) / 100U;
    g_cs.cpu_hz   = SystemCoreClock;
    g_cs.avg_ns   = (uint32_t)(((uint64_t)g_cs.avg_x100 * 10000000ULL) / SystemCoreClock);
    g_cs.max_ns   = (uint32_t)(((uint64_t)g_cs.max * 1000000000ULL) / SystemCoreClock);
    g_cs.done     = 1;
}

static void bench_task(void *arg)
{
    (void)arg;
#if CS_BENCH_FPU
    /* Touch the FPU once: CONTROL.FPCA = 1 for this task from now on, so every
     * switch in/out of it uses the extended frame (S0-S15 by hardware,
     * S16-S31 by PendSV). Compare with CS_BENCH_FPU=0 to see the FPU cost. */
    volatile float f = 1.5f;
    f = f * 2.25f;
    (void)f;
#endif

    os_delay(CS_BENCH_START_DELAY_MS);

    /* Barrier: the second task to arrive starts the run */
    uint32_t pm = os_enter_critical();
    if (++s_arrived == 2U) {
        g_cs.calib = measure_read_overhead();
        os_tick_suspend();
        s_armed = 1;
    }
    os_exit_critical(pm);

    while (!s_armed) {
        os_yield();                  /* hand over to the other task */
    }

    while (g_cs.count < CS_BENCH_SAMPLES) {
        s_t_yield = dwt_cycles();
        os_yield();                  /* <-- the measured context switch */
        uint32_t t1 = dwt_cycles();
        record(t1 - s_t_yield);      /* s_t_yield was written by the OTHER task */
    }

    pm = os_enter_critical();
    uint32_t first_to_finish = !s_finished;
    s_finished = 1;
    if (first_to_finish) {
        finalize();
        os_tick_resume();
    }
    os_exit_critical(pm);

    if (first_to_finish) {
        cs_bench_complete();
    }
    /* returning retires this task (os_task_exit) */
}

void cs_bench_create_tasks(void)
{
    g_cs.done       = 0;
    g_cs.count      = 0;
    g_cs.sum        = 0;
    g_cs.min        = 0xFFFFFFFFUL;
    g_cs.max        = 0;
    g_cs.max_index  = 0;
    g_cs.fpu_frames = CS_BENCH_FPU;

    /* Is CYCCNT really counting? (it isn't in most emulators) */
    uint32_t a = dwt_cycles();
    for (volatile uint32_t i = 0; i < 10U; i++) { }
    g_cs.dwt_ok = (dwt_cycles() != a) ? 1U : 0U;

    (void)os_task_create(bench_task, (void *)0, CS_BENCH_PRIO, s_stack_a, 256, "bench_a");
    (void)os_task_create(bench_task, (void *)1, CS_BENCH_PRIO, s_stack_b, 256, "bench_b");
}
